﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurtleChallenge
{
    public class EndPosition:Position
    {
        public EndPosition(int x, int y) : base(x, y) { }
    }
}
