﻿using static Utilities.Utils;

namespace TurtleChallenge
{
    public class MoveEventArgs
    {
        public Moves move { get; set; }
    }
}